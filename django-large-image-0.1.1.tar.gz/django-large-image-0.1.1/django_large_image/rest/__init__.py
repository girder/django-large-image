# flake8: noqa: F401
from django_large_image.rest.data import DataViewSet
from django_large_image.rest.metadata import MetaDataViewSet
from django_large_image.rest.standalone import ListColormapsView, ListTileSourcesView
from django_large_image.rest.tiles import TilesViewSet


class LargeImageViewSet(DataViewSet, MetaDataViewSet, TilesViewSet):
    pass
